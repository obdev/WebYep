// Das Stile-Set muss den Namen "WebYepStyles" tragen

CKEDITOR.stylesSet.add('WebYepStyles',[

	// block styles:
	{ name : 'Note / Hinweis', element : 'p', styles : { 'margin' : '10px', 'padding': '10px', 'border': '1px solid gray' } },

	// inline styles:
	{ name : 'Important / Wichtig', element : 'span', styles : { 'font-weight': 'bold', 'color': 'red'} }
]);

// Der letzte Eintrag darf nicht mit einem Komma (Beistrich) enden!!!