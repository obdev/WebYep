<? // WebYep init WebYepV1
/* ><table><tr><td bgcolor=white><h2>WebYep meldet: Fehler, PHP inaktiv</h2>
<font color=red>Der PHP-Code in dieser Seite wird nicht durchgef&uuml;hrt!<ul>
<li>Entweder rufen Sie die Seite nicht &uuml;ber den WebServer sondern direkt
von Ihrer Festplatte aus auf (zB. mittels &quot;Voransicht im Browser&quot; im Dreamweaver).</li>
<li>Oder Sie haben der Datei nicht die richtige Dateierweiterung (extension) gegeben -
WebYep-Seiten m&uuml;ssen die Erweiterung &quot;.php&quot; (oder &quot;.php4&quot; je nach WebSever)
aufweisen und <b>nicht</b> ".html" bzw. ".htm"!</li>
</ul></font></td></tr></table><!--
*/
$webyep_sIncludePath = "./";
$iDepth = 0;
while (!file_exists($webyep_sIncludePath . "webyep-system")) {
	$iDepth++;
	if ($iDepth > 10) {
		error_log("webyep-system folder not found.", 0);
		echo "<html><head><title>WebYep!</title></head><body><b>WebYep:</b> Diese Seite kann leider nicht angezeigt werden <br>Problem: Der webyep-system Ordner konnte nicht gefunden werden!</body></html>";
		exit;
	}
	$webyep_sIncludePath = ($webyep_sIncludePath == "./") ? ("../"):("$webyep_sIncludePath../");
}
$webyep_sIncludePath .= "webyep-system/programm";
include("$webyep_sIncludePath/webyep.php");
// -->?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>WebYep - erweiterte Formatierung</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="stile.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="100%" border="0" cellspacing="0" cellpadding="6">
  <tr>
    <td class="hauptmenue"><a href="#"><span class="selektiert">Startseite</span></a> | <a href="#">Unsere Gemeinde</a> | <a href="vereine.php">Vereine</a> | <a href="#">Kontakt</a> </td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="6">
  <tr>
    <td><h1>Startseite<a href="#"></a> </h1></td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="5" cellpadding="1">
  <tr>
    <td width="1%" align="left" valign="top" nowrap><p>Dies ist eine Test-Website
        zur Erl&auml;uterung der Formatierung vom WebYep-Elementen mittels CSS. </p>
      <p class="hinweis">Klicken Sie im obigen Hauptmen&uuml; bitte auf den Men&uuml;punkt &quot;Vereine&quot;! </p></td>
  </tr>
</table>
<hr size="1" noshade>
<? webyep_logonButton(true); // WebYepV1 ?>
</body>
</html>
