<? // WebYep init WebYepV1
/* ><table><tr><td bgcolor=white><h2>WebYep meldet: Fehler, PHP inaktiv</h2>
<font color=red>Der PHP-Code in dieser Seite wird nicht durchgef&uuml;hrt!<ul>
<li>Entweder rufen Sie die Seite nicht &uuml;ber den WebServer sondern direkt
von Ihrer Festplatte aus auf (zB. mittels &quot;Voransicht im Browser&quot; im Dreamweaver).</li>
<li>Oder Sie haben der Datei nicht die richtige Dateierweiterung (extension) gegeben -
WebYep-Seiten m&uuml;ssen die Erweiterung &quot;.php&quot; (oder &quot;.php4&quot; je nach WebSever)
aufweisen und <b>nicht</b> ".html" bzw. ".htm"!</li>
</ul></font></td></tr></table><!--
*/
$webyep_sIncludePath = "./";
$iDepth = 0;
while (!file_exists($webyep_sIncludePath . "webyep-system")) {
	$iDepth++;
	if ($iDepth > 10) {
		error_log("webyep-system folder not found.", 0);
		echo "<html><head><title>WebYep!</title></head><body><b>WebYep:</b> Diese Seite kann leider nicht angezeigt werden <br>Problem: Der webyep-system Ordner konnte nicht gefunden werden!</body></html>";
		exit;
	}
	$webyep_sIncludePath = ($webyep_sIncludePath == "./") ? ("../"):("$webyep_sIncludePath../");
}
$webyep_sIncludePath .= "webyep-system/programm";
include("$webyep_sIncludePath/webyep.php");
// -->?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>WebYep - erweiterte Formatierung</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="stile.css" rel="stylesheet" type="text/css">
</head>
<?
	// Dieser Programmteil dient dazu, die Inhalte der WebYep-Elemente beim
	// ersten Aufruf der Seite zu bef�llen:
	$bContentGenerated = false;
	$oMenu = new WYMenuElement("Vereine", false, $_SERVER['PHP_SELF'], "", "");
	if (!count($oMenu->dContent[WY_DK_ITEMSARRAY])) {
		$oMenu->setItems(array(1 => "#Sport", 2 => "___Fu�ball", 3 => "___Volleyball", 4 => "#Kultur", 5 => "___Schauspielgruppe", 6 => "___Gesangsverein"));
		$oMenu->save();

		$iCurrentDI = $goApp->oDocument->iDocumentInstance;

		$goApp->oDocument->iDocumentInstance = 2;
		$oST = new WYShortTextElement("Vereinsname", false);
		$oST->setText("FC Libero");
		$oST->save();
		$oLT = new WYLongTextElement("Beschreibung", false, "");
		$oLT->setText(str_repeat("Dies ist ein Blindtext. ", 15));
		$oLT->save();

		$goApp->oDocument->iDocumentInstance = 3;
		$oST = new WYShortTextElement("Vereinsname", false);
		$oST->setText("VC Powerblock");
		$oST->save();
		$oLT = new WYLongTextElement("Beschreibung", false, "");
		$oLT->setText(str_repeat("Und das ist auch ein Blindtext. ", 15));
		$oLT->save();

		$goApp->oDocument->iDocumentInstance = $iCurrentDI;
		$bContentGenerated |= true;
	}

	if ($bContentGenerated) {
		echo '<script language="JavaScript">';
		echo 'window.alert("WebYep Inhalte wurde generiert!");';
		echo "</script>\n";
	}
?>
<body>
<table width="100%" border="0" cellspacing="0" cellpadding="6">
  <tr>
    <td class="hauptmenue"><a href="index.php">Startseite</a> | <a href="#">Unsere Gemeinde</a> | <a href="#"><span class="selektiert">Vereine</span></a> | <a href="#">Kontakt</a> </td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="6">
  <tr>
    <td><h1>Vereine<a href="#"></a> </h1></td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="5" cellpadding="1">
  <tr>
    <td width="1%" align="left" valign="top" nowrap class="vereinsmenue"><? webyep_menu("Vereine", false, "vereine.php", "", "", ""); // WebYepV1 ?>
    </td>
    <td width="100%" align="left" valign="top"><h2>
      <? webyep_shortText("Vereinsname", false); // WebYepV1 ?>
    </h2>
    <p>
      <? webyep_image("Foto", false, 'hspace="10" align="left"'); // WebYepV1 ?>
      <? webyep_longText("Beschreibung", false, ""); // WebYepV1 ?>
    </p>
    <br clear="all">
    <h3>Veranstaltungen:
    </h3>
<!-- Hier steht der WebYep Schleifen-Start nach dem Einf�gen: -->
    <table border="0" cellpadding="4" cellspacing="0">
	<tr>
		<td class="tabellenBeschriftung">Datum</td>
		<td class="tabellenBeschriftung">Zeit</td>
		<td class="tabellenBeschriftung">Ort</td>
		<td class="tabellenBeschriftung">Beschreibung</td>
	</tr>
<!-- Verschieben Sie den Schleifen-Start hier her (die ganze Zeile) -->
     <tr>
        <td align="left" valign="top" nowrap>
           <!-- F�gen Sie hier den PHP Code f�r die Schleifen-Editier-Kn�pfe ein: -->
           <? webyep_shortText("Datum", false); // WebYepV1 ?>
        </td>
        <td align="left" valign="top" nowrap>
           <? webyep_shortText("Zeit", false); // WebYepV1 ?>
        </td>
        <td align="left" valign="top" nowrap>
           <? webyep_shortText("Ort", false); // WebYepV1 ?>
        </td>
        <td align="left" valign="top">
           <? webyep_longText("Text", false, ""); // WebYepV1 ?>
        </td>
     </tr>
<!-- Verschieben Sie das WebYep Schleifen-Ende hier her (die ganze Zeile) -->
    </table>
<!-- Hier steht das WebYep Schleifen-Ende nach dem Einf�gen: -->
    </td>
  </tr>
</table>
<hr size="1" noshade>
<? webyep_logonButton(true); // WebYepV1 ?>
</body>
</html>
