<? // WebYep init WebYepV1
/* ><table><tr><td bgcolor=white><h2>WebYep message: Error, PHP inactive</h2>
<font color=red>The PHP code in this page can not be executed!<ul>
<li>Are you launching this page directly form your harddisc (e.g. via Dreamweavers
&quot;Preview in Browser&quot instead of accessing it via a webserver?</li>
<li>Has this file the correct file extension for PHP scripts?
WebYep pages must have the &quot;.php&quot; extension (or &quot;.php4&quot; depending on the webserver used)
and <b>not</b> ".html" or ".htm"!</li>
</ul></font></td></tr></table><!--
*/
$webyep_sIncludePath = "./";
$iDepth = 0;
while (!file_exists($webyep_sIncludePath . "webyep-system")) {
	$iDepth++;
	if ($iDepth > 10) {
		error_log("webyep-system Ordner nicht gefunden.", 0);
		echo "<html><head><title>WebYep!</title></head><body><b>WebYep:</b> This page can not be displayed <br>Problem: The webyep-system folder was not found!</body></html>";
		exit;
	}
	$webyep_sIncludePath = ($webyep_sIncludePath == "./") ? ("../"):("$webyep_sIncludePath../");
}
if (file_exists("$webyep_sIncludePath/webyep-system/programm")) $webyep_sIncludePath .= "webyep-system/programm";
else $webyep_sIncludePath .= "webyep-system/program";
include("../webyep-tutorial-gemeinde_en/$webyep_sIncludePath/webyep.php");
// -->?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>WebYep - extended features</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="stile.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="100%" border="0" cellspacing="0" cellpadding="6">
  <tr>
    <td class="mainmenu"><a href="#"><span class="selected">Home</span></a> | <a href="#">Our
        Village</a> | <a href="clubs.php">Clubs</a> | <a href="#">Contact</a> </td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="6">
  <tr>
    <td><h1>Home<a href="#"></a> </h1></td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="5" cellpadding="1">
  <tr>
    <td width="1%" align="left" valign="top" nowrap><p>This is a test website
        to explain the use of CSS for formatting WebYep Elements.</p>
      <p class="notice">Please click the &quot;Clubs&quot; menu item above! </p></td>
  </tr>
</table>
<hr size="1" noshade>
<? webyep_logonButton(true); // WebYepV1 ?>
</body>
</html>
