<?php // WebYep init WebYepV1
/* ><table><tr><td bgcolor=white><h2>WebYep message: Error, PHP inactive</h2>
<font color=red>The PHP code in this page can not be executed!<ul>
<li>Are you launching this page directly form your harddisc (e.g. via Dreamweavers
"Preview in Browser" instead of accessing it via a webserver?</li>
<li>Has this file the correct file extension for PHP scripts?
WebYep pages must have the ".php" extension and <b>not</b> ".html" or ".htm"!</li>
</ul></font></td></tr></table><!--
*/
$webyep_sIncludePath = "./";
$iDepth = 0;
while (!file_exists($webyep_sIncludePath . "webyep-system")) {
  $iDepth++;
  if ($iDepth > 10) {
    error_log("webyep-system folder not found!", 0);
    echo "<html><head><title>WebYep</title></head><body><b>WebYep:</b> This page can not be displayed <br>Problem: The webyep-system folder was not found!</body></html>";
    exit;
  }
  $webyep_sIncludePath = ($webyep_sIncludePath == "./") ? ("../"):("$webyep_sIncludePath../");
}
if (file_exists("${webyep_sIncludePath}webyep-system/programm")) $webyep_sIncludePath .= "webyep-system/programm";
else $webyep_sIncludePath .= "webyep-system/program";
include("$webyep_sIncludePath/webyep.php");
// -->?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta http-equiv="Content-Type" content="text/html;charset=utf-8"/>
  <meta http-equiv="Content-Script-Type" content="text/javascript"/>
  <meta http-equiv="Content-Style-Type" content="text/css"/>
  <title>WebYep Accordion Effect</title>
  <style type="text/css">
    body {
      font: 12px/18px sans-serif;
      color: #002;
      margin: 0;
      padding: 0;
      overflow-y: scroll;
    }
    .page {
      width: 800px;
      margin: 0 auto;
    }
    .header {
      color: #004;
      text-shadow: 0 1px 0 #eee;
      border-radius: 0 0 8px 8px;
      background-color: #ddd;
      background: -moz-linear-gradient(top, #eee, #bbb);
      background: -webkit-gradient(linear, left top, left bottom, from(#eee), to(#bbb));
    }
    .logon {
      float: right;
      margin: 10px;
    }
    h1, h2 {
      margin: 0;
      padding: 10px;
    }
    .content {
      padding: 10px;
    }

    .accordionHeader {
      border-top: 1px solid #fff;
      border-bottom: 1px solid #fff;
      background-color: #d9e4eb;
      cursor: pointer;
      font-weight: bold;
      text-shadow: 0 1px 0 #eee;
      padding: 2px 5px 0;
    }
    .accordionHeader:hover {
      background-color: #c6d9e6;
    }
    .accordionContent {
      margin: 0;
      padding: 5px 5px 0;
      background-color: #f0f0f0;
    }
    .accordionPadding {
    }
    .accordionContent p {
      margin: 0;
      padding: 0 0 5px 0;
    }
  </style>

  <!-- include jQuery library -->
  <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>

  <!-- namespacing jQuery -->
  <script type="text/javascript">/*<![CDATA[*/
    var WY = window.WY || {}; WY.$ = jQuery.noConflict(true);
  /*]]>*/</script>

  <!--  initialize accordion when the DOM is ready -->
  <script type="text/javascript">/*<![CDATA[*/
    WY.$(document).ready(function(){
      // check whether we are in edit mode
      if (!WY.$('.accordion').find('.WebYepLoopAddButton').length){
        // determine height of every .accordionContent and write it to the DOM
        WY.$('.accordionContent').each(function(){
          WY.$(this).css({'height':WY.$(this).height()+'px'});
        });
        // hide all .accordionContent items
        WY.$('.accordionContent').css({'display':'none'});
        // attach a click handler to each .accordionHeader
        WY.$('.accordionHeader').each(function(){
          WY.$(this).click(function(){
            WY.$('.accordionContent').slideUp(350);
            WY.$(this).siblings('.accordionContent').stop().slideToggle(350);
          });
        });
      }
      // test functions
      window.N = WY.$(".accordionHeader");
      window.test = function() {
        var x = Math.floor(Math.random() * N.length);
        N.slice(x,x+1).click();
        window.T = window.setTimeout(window.test, 1500);
      }
      window.start = function() {window.T = window.setTimeout(window.test, 1500);}
      window.stop = function() {window.clearTimeout(window.T);}
    });
  /*]]>*/</script>
  <!-- === end of demo code === -->
</head>
<body>
  <div class="page">
    <div class="header">
      <div class="logon"><?php webyep_logonButton(true); ?></div>
      <h1>WebYep Accordion Effect</h1>
      <h2>&copy; 2012 Objective Development Software GmbH</h2>
    </div>
    <div class="content">
      <div>
        <h3>Morbi at sapien orci</h3>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse vel velit et metus rhoncus viverra nec eget nunc.
        In ullamcorper dui id nibh fringilla convallis. Suspendisse potenti. Cum sociis natoque penatibus et magnis dis parturient
        montes, nascetur ridiculus mus.</p>
      </div>

      <div class="accordion">
      <?php foreach (WYLoopElement::aLoopIDs("newsLoop") as $webyep_oCurrentLoop->iLoopID) { $webyep_oCurrentLoop->loopStart(true); ?>
        <div>
          <div class="accordionHeader"><?php webyep_shortText("newsHeader", false); ?></div>
          <div class="accordionContent"><?php webyep_richText("newsContent", false, "", true); ?></div>
        </div>
      <?php $webyep_oCurrentLoop->loopEnd(); } ?>
      </div>

      <div>
        <p>Nulla facilisi. Morbi at sapien orci. Fusce augue arcu, feugiat vel condimentum sed, rutrum nec est. Ut sit amet lacus ipsum, non mattis eros.
        Cras consectetur cursus urna sed laoreet. Sed non libero ut purus pharetra adipiscing. Suspendisse fermentum massa et felis
        tempor iaculis. Fusce aliquam rhoncus nisl, at pulvinar dui lobortis non. Duis ac arcu lorem.</p>
        <p>Integer vehicula, felis venenatis tempus malesuada, tellus nisi ullamcorper velit, id feugiat dui enim quis ante. Nam vitae
        nisi tortor, eget gravida mauris. Sed feugiat dolor et justo pretium suscipit? Cras lobortis nulla eros, ac
        placerat ligula. Nam lacinia ullamcorper nibh, non vulputate nunc iaculis ut.</p>
      </div>
    </div>
  </div>
</body>
</html>