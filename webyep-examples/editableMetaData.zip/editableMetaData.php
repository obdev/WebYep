<?php // WebYep init WebYepV1
/* ><table><tr><td bgcolor=white><h2>WebYep message: Error, PHP inactive</h2>
<font color='red'>The PHP code in this page can not be executed!<ul>
<li>Are you launching this page directly form your harddisc (e.g. via Dreamweavers "Preview in Browser" instead of accessing it via a webserver?</li>
<li>Has this file the correct file extension for PHP scripts? WebYep pages must have the ".php" extension and <b>not</b> ".html" or ".htm"!</li>
</ul></font></td></tr></table><!--
*/
$webyep_sIncludePath = './'; $iDepth = 0;
while (!file_exists($webyep_sIncludePath . 'webyep-system')) {if ($iDepth++ > 10) {error_log('webyep-system folder not found!', 0);
echo '<html><head><title>WebYep</title></head><body><b>WebYep:</b> This page can not be displayed<br>Problem: The webyep-system folder was not found!</body></html>';
exit;} $webyep_sIncludePath = ($webyep_sIncludePath == './') ? ('../'):("$webyep_sIncludePath../");}
if (file_exists("${webyep_sIncludePath}webyep-system/programm")) $webyep_sIncludePath .= 'webyep-system/programm';
else $webyep_sIncludePath .= 'webyep-system/program';
include("$webyep_sIncludePath/webyep.php");
// -->?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta http-equiv="Content-Type" content="text/html;charset=utf-8"/>
  <meta http-equiv="Content-Style-Type" content="text/css"/>
  <meta http-equiv="Content-Script-Type" content="text/javascript"/>
  <title><?php echo webyep_sShortTextContent("PageTitle", false); ?></title>
  <style type="text/css">
    /* general styles */
    html, body {margin:0; padding:0;}
    body {overflow-y:scroll}
    .page {width:800px; margin:0 auto; font:14px sans-serif;}
    .header {background-color:#eee; border-radius: 0 0 8px 8px; box-shadow:0 0 1px #888;}
    .header h1, .header h2, .header p {margin:0; padding:10px;}
    .header h1 {font-size:1.3em; color:orange; text-shadow:0 1px 0 #888;}
    .header h2 {font-size:1.1em;}
    .header p {font-size:1.0em;}
    .logon {float:right; margin:5px; padding:2px 2px 0 1px; border-radius:6px; background-color:#ccc;}
    .content {padding:10px;}
    .content h1 {margin:3px 0; font-size:1.2em;}
    .content p {margin:3px 0 10px;}

    /* styles for the meta data panel (only visible in edit mode) */
    .metaControls {background-color:#ddd; border:solid 1px #ccc; border-radius:5px; padding: 2px 7px 5px; clear:both; margin:10px 0;}
    .metaControls em {position:relative; top:-0.5em; left:0; border:solid 1px #ccc; border-radius:5px; background-color:#eee; padding:2px 4px 1px;}
  </style>
</head>
<body>
  <div class="page">
    <div class="header">
      <div class="logon"><?php webyep_logonButton(true); ?></div>
      <h1>WebYep Examples</h1><h2>Editable Meta Data</h2>
      <p>When WebYep is in edit mode there will be an input field for the page title. Normal visitors won't see this.</p>
    </div>
    <div class="content">

      <?php if (webyep_bIsEditMode()) { ?>
      <div class="metaControls">
        <em>Meta Data</em>
        <div>Page Title: <?php webyep_shortText("PageTitle", false); ?></div>
      </div>
      <?php } ?>

      <h1>Lorem Ipsum Dolor Sit Amet</h1>
      <p>
        Etiam scelerisque, metus quis fringilla consequat, mi ante iaculis purus, aliquam ultrices diam purus eleifend lectus.
        Integer ipsum mauris, ultricies eget lobortis vitae, tincidunt auctor sem. Etiam velit magna, pellentesque vitae posuere vel,
        fringilla a augue. Cras ac ipsum augue. Donec lobortis dictum dolor vitae gravida. Morbi urna ipsum, tristique sed porttitor
        non, iaculis sit amet nisl. Mauris volutpat felis ac justo luctus in fringilla velit placerat. Vestibulum sed aliquet diam.
        Nam congue ullamcorper diam sed ultrices. Suspendisse sapien dolor, sollicitudin at mattis quis, dignissim nec odio. Donec
        ut porta sem? Curabitur ultricies nisl magna, sit amet tempor ligula. Vivamus ac massa ligula; vitae cursus sem. Phasellus
        tristique, eros sed tincidunt aliquet, lorem orci elementum dui, ac laoreet tortor libero vel nunc.
      </p>

    </div>
  </div>
</body>
</html>