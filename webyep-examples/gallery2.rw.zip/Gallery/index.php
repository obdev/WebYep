<?php // ><!--
$webyep_sIncludePath = "./";
$iDepth = 0;
while (!file_exists($webyep_sIncludePath . "webyep-system")) {
	$iDepth++;
	if ($iDepth > 10) {
		error_log("webyep-system folder not found.", 0);
      break;
	}
	$webyep_sIncludePath = ($webyep_sIncludePath == "./") ? ("../"):("$webyep_sIncludePath../");
}
if (file_exists("$webyep_sIncludePath/webyep-system/programm")) $webyep_sIncludePath .= "webyep-system/programm";
else $webyep_sIncludePath .= "webyep-system/program";
$sMain = "$webyep_sIncludePath/webyep.php";
if (file_exists($sMain)) include($sMain);
// --> <dummy ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="generator" content="RapidWeaver" />
		
		<title>Gallery Example</title>
		<link rel="stylesheet" type="text/css" media="screen" href="rw_common/themes/aqualicious/styles.css"  />
		<link rel="stylesheet" type="text/css" media="print" href="rw_common/themes/aqualicious/print.css"  />
		<link rel="stylesheet" type="text/css" media="handheld" href="rw_common/themes/aqualicious/handheld.css"  />
		<link rel="stylesheet" type="text/css" media="screen" href="rw_common/themes/aqualicious/css/styles/blue.css" />
		<link rel="stylesheet" type="text/css" media="screen" href="rw_common/themes/aqualicious/css/sidebar/sidebar_right.css" />
		<link rel="stylesheet" type="text/css" media="screen" href="rw_common/themes/aqualicious/css/font/modern.css" />
		<link rel="stylesheet" type="text/css" media="screen" href="rw_common/themes/aqualicious/css/background/white.css" />
		<link rel="stylesheet" type="text/css" media="screen" href="rw_common/themes/aqualicious/css/width/1000.css" />
		
		
		<style type="text/css" media="all">/* Heading tag containing the page heading */
.WebYepPageHeading {
	font-size: 2em;
	padding: 0;
	margin-top: 0;
	margin-bottom: 1em;
}

/* Heading tag containing the block heading */
.WebYepBlockHeading {
	font-size: 1.5em;
	padding: 0;
	margin-top: 0;
	margin-bottom: 0.5em;
}

/* div tag around left photo */
.WebYepLeftPhoto {
	padding: 10px;
	border: 1px dotted black;
}

/* div tag around right photo */
.WebYepRightPhoto {
	padding: 10px;
	border: 1px dotted black;
}

/* The editable text */
.WebYepText {
}

/* Paragraph containing the WYAttachment element */
.WebYepAttachment {
	border-top: 1px solid grey;
	border-bottom: 1px solid grey;
	margin: 1em;
	padding: 0.5em;
}

/* The descriptive text for the attachment */
.WebYepAttachmentDescription {
}

/* The filename of the attachment, containing the link */
.WebYepAttachmentFilename {
	padding: 4px;
}

/* div tag around center photo */
.WebYepCenterPhoto {
}

/* Spacer div after each block */
.WebYepBlockPadding {
}

/* designing tables inside the editable text */
/* tables can be created with the "|" character */
.WebYepText table {
	margin: 0px;
	padding: 0px;
	border-collapse: collapse;
}
.WebYepText td {
	margin: 0px;
	padding: 6px;
	border: 1px solid black;
}

/* example custom text style */
.WebYepText .EXAMPLE {
	font-weight: bold;
	color: #bc0000;
}


/* image gallery */

.WebYepGalleryContainer {
    border-spacing:  20px;
    empty-cells:         hide;
}
.WebYepGalleryContainer td {
    border:                 1px solid black;
    padding:              0;
    height:                  120px;
    vertical-align:      middle;
    text-align:             center;
}
.WebYepGalleryText {
    display:                none;
}
.WebYepGalleryImage + div + .WebYepGalleryText {
    display:                block;
}
.WebYepGalleryImage img {
	border-left:       1px solid grey;
	border-top:       1px solid grey;
	border-right:     1px solid black;
	border-bottom: 1px solid black;
}

/* sidebar menu */

/* The div enclosing the menu */
.WebYepMenu {
}

/* The tree titles */
.WebYepMenu li.WebYepMenuTitle {
	font-weight: bold;
}

/* Normal items */
.WebYepMenu li.WebYepMenuItem {
	font-weight: normal;
}

/* All trees */
.WebYepMenu ul {
	padding: 0px;
}

/* All items */
.WebYepMenu ul li {
	list-style-position: inside;
	list-style-type: none;
	font-size: 1em;
	margin: 0px 0px 5px 0px;
	padding: 0px;
	line-height: 1.2em;
}

/* Second level trees */
.WebYepMenu ul ul {
	margin-bottom: 10px;
}

/* Second level items */
.WebYepMenu ul ul li {
	font-size: 0.9em;
	margin: 5px 0px 0px 1em;
	padding: 0px;
}

/* Trees of third level and below */
.WebYepMenu ul ul ul {
   font-size: 0.8em;
}

/* Items of third level and below */
.WebYepMenu ul ul ul li {
	font-size: 0.8em;
	margin-left: 2em;
}

/* The first item in each submenu */
.WebYepMenu li li.WebYepMenuFirstItem {
}

/* The actual links */
.WebYepMenu a:link, .WebYepMenu a:visited, .WebYepMenu a:active {
	text-decoration: none;
}

/* The actual links when hovering */
.WebYepMenu a:hover {
}

/* The actual link of the currently selected item */
.WebYepMenu a:link.WebYepMenuCurrentItem, .WebYepMenu a:visited.WebYepMenuCurrentItem, .WebYepMenu a:active.WebYepMenuCurrentItem {
	text-decoration: none;
	color: #7e7e7e;
}

/* The actual link of the currently selected item when hovering */
.WebYepMenu a:hover.WebYepMenuCurrentItem {
	color: #7e7e7e;
}
</style>
		
		<script type="text/javascript" src="rw_common/themes/aqualicious/javascript.js"></script>
		
		
		
		
	</head>
<body>
<div id="gradient"></div>
<div id="navcontainer"><!-- Start Navigation -->
	<ul><li><a href="./" rel="self" id="current">Gallery Example</a></li></ul>
</div><!-- End navigation -->

<div id="container"><!-- Start container -->
	<div id="pageHeader"><!-- Start page header -->
		
		<h1>WebYep Gallery&sup2;</h1>
		<h2>Doing wonderful things with WebYep, the tiny, shiny CMS...</h2>
	</div><!-- End page header -->

	<div id="sidebarContainer"><!-- Start Sidebar wrapper -->
		<div id="sidebar"><!-- Start sidebar content -->
			<h1 class="sideHeader"></h1><!-- Sidebar header -->
			 <br /><!-- sidebar content you enter in the page inspector -->
			<!-- Sidebar Menu: ========================================= -->
<div class="WebYepMenu">
<?php webyep_menu("SidebarMenu", false, $_SERVER['PHP_SELF'], "", "", ""); ?>
</div> <!-- sidebar content such as the blog archive links -->
		</div><!-- End sidebar content -->
	</div><!-- End sidebar wrapper -->
	
	<div id="contentContainer"><!-- Start main content wrapper -->
		<div id="content"><!-- Start content -->
			<div class="contentSpacer"></div><!-- this makes sure the content is long enough for the design -->
			<!-- Mode: export -->
<?php
	$iLeftPhotoPadding = 10;
	$iRightPhotoPadding = 10;
	$iLeftPhotoWidth = false ? 150:0;
	$iRightPhotoWidth = false ? 150:0;
	$iCenterPhotoPadding = 10;
	$iCenterPhotoWidth = false ? 300:0;
	$iBlockPadding = 20;

    if (!isset($iPageID)) $iPageID = 0;

    if (!function_exists("webyep_bCheckImage")) {
        function webyep_bCheckImage($sN, $iFixedW, &$sWCSS)
        {
            $bRet = false;

            $sWCSS = "";
            $oElement = new WYImageElement($sN, false, $iFixedW ? "width=\"$iFixedW\"":"", "", "");
            $sContent = $oElement->sDisplay();
            if ($sContent) {
                if ($iFixedW) $iW = $iFixedW;
                else {
                    $oImg = $oElement->oImage();
                    $iW = $oImg ? $oImg->iWidth():0;
                }
                $sWCSS = $iW ? (" width: " . $iW . "px;"):"";
                $bRet = true;
            }
            return $bRet;
        }
    }

    if ($iPageID) $sFieldPostfix = "_$iPageID";
    else $sFieldPostfix = "";
    $iPageID++;
	$sWidthCSS = "";
?>
<h1 class="WebYepPageHeading"><?php webyep_shortText("PageHeading$sFieldPostfix", false); ?></h1>
<!-- Loop Start: ======================================== -->
<?php foreach (WYLoopElement::aLoopIDs("BlockLoop$sFieldPostfix") as $webyep_oCurrentLoop->iLoopID) { $webyep_oCurrentLoop->loopStart(true); ?>
<!-- Gallery: ========================================= -->
<?php
   if (function_exists("webyep_gallery")) webyep_gallery("ImageGallery", false, 90, 90, 5, 600, 700, 120);
   else echo "<p style=\"color: red; font-weight: bold\">Please install the current version of the webyep-system folder on this server to use the Image Gallery Element!</p>";
?><!-- Block Padding: ====================================== -->
<?php if ($iBlockPadding) printf('<div style="font-size: 0px; line-height: 0px; height: %spx;" class="WebYepBlockPadding"></div>', $iBlockPadding); ?>
<!-- Loop End: =========================================== -->
<?php $webyep_oCurrentLoop->loopEnd(); } ?>
<div><?php webyep_logonButton(true); ?></div>
			<div class="clear"></div>
			<div class="clearer"></div>
		</div><!-- End content -->
	</div><!-- End main content wrapper -->

	<div class="clearer"></div>
	<div id="footer"><!-- Start Footer -->
		<div id="breadcrumbcontainer"><!-- Start the breadcrumb wrapper -->
			
		</div><!-- End breadcrumb -->
		<p>&copy; 2011 Objective Development</p>
	</div><!-- End Footer -->
</div><!-- End container -->
</body>
</html>
