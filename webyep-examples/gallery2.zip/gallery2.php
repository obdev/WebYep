<?php // WebYep init WebYepV1
/* ><table><tr><td bgcolor=white><h2>WebYep message: Error, PHP inactive</h2>
<font color=red>The PHP code in this page can not be executed!<ul>
<li>Are you launching this page directly form your harddisc (e.g. via Dreamweavers
"Preview in Browser" instead of accessing it via a webserver?</li>
<li>Has this file the correct file extension for PHP scripts?
WebYep pages must have the ".php" extension and <b>not</b> ".html" or ".htm"!</li>
</ul></font></td></tr></table><!--
*/
$webyep_sIncludePath = "./";
$iDepth = 0;
while (!file_exists($webyep_sIncludePath . "webyep-system")) {
    $iDepth++;
    if ($iDepth > 10) {
        error_log("webyep-system folder not found!", 0);
        echo "<html><head><title>WebYep</title></head><body><b>WebYep:</b> This page can not be displayed <br>Problem: The webyep-system folder was not found!</body></html>";
        exit;
    }
    $webyep_sIncludePath = ($webyep_sIncludePath == "./") ? ("../"):("$webyep_sIncludePath../");
}
if (file_exists("${webyep_sIncludePath}webyep-system/programm")) $webyep_sIncludePath .= "webyep-system/programm";
else $webyep_sIncludePath .= "webyep-system/program";
include("$webyep_sIncludePath/webyep.php");
// -->?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html;charset=utf-8"/>
<title>WebYep-Gallery²</title>
<style type="text/css">
html, body {
    margin:                 0;
    padding:                0;
    font-family:            sans-serif;
    font-size:              12px;
}
#page {
    background-color:       #eee;
    width:                  999px;
    margin:                 0 auto;
    border:                 solid 1px #888;
    min-height:             999px;
}
#head {
    height:                 35px;
    font-size:              20px;
    background-color:       #aaa;
    color:                  #fff;
    padding:                35px;
}
.WebYepGalleryContainer {
    border-spacing:         20px;
    empty-cells:            hide;
}
.WebYepGalleryContainer td {
    border:                 1px solid #aaa;
    background-color:       #f4f4f4;
    padding:                0;
    height:                 120px;
    vertical-align:         middle;
    text-align:             center;
    -moz-box-shadow:        0 0 3px 1px #ccc;
    -webkit-box-shadow:     0 0 3px 1px #ccc;
    -moz-border-radius:     3px;
    border-radius:          3px;
}
.WebYepGalleryImage img {
    -moz-box-shadow:        0 0 2px 0 #666;
    -webkit-box-shadow:     0 0 2px 0 #666;
}
.WebYepGalleryImage {
    line-height:            0px;
}
.WebYepGalleryText {
    display:                none;
}
.WebYepGalleryImage + div + .WebYepGalleryText {
    display:                block;
}
.WebYepMenu {
    list-style-type:        none;
    font-size:              16px;
}
a.WebYepMenuItem {
    color:                  #888;
    text-decoration:        none;
}
a.WebYepMenuCurrentItem {
    color:                  #f88 !important;
}
a.WebYepMenuItem:hover {
    color:                  #fc8;
}
img {
    border:                 none;
}
#menu {
    float:                  left;
}
#gallery {
    margin:                 0 0 0 200px;
}
#login {
    position:               fixed;
    top:                    5px;
    left:                   5px;
}
</style>
</head>
<body>
<div id="page">
    <div id="head">WebYep-Gallery<sup>2</sup></div>
    <div id="body">
        <div id="menu"><?php webyep_menu("Menu", false, "gallery2.php", "", "", ""); ?></div>
        <div id="gallery">
            <?php webyep_gallery("Gallery", false, 90, 90, 5, 600, 700, 120); ?>
        </div>
    </div>
</div>
<div id="login"><?php webyep_logonButton(true); ?></div>
</body>
</html>