<?php
  $oCurrentDocument = $goApp->oDocument;
  $goApp->oDocument = new WYDocument(new WYURL(basename(__FILE__)));
  $goApp->oDocument->setDocumentInstance(0);
  foreach (WYLoopElement::aLoopIDs("globalLoop1") as $webyep_oCurrentLoop->iLoopID) {
    $webyep_oCurrentLoop->loopStart(true);
?>

<div>
  <?php webyep_longText("Text", false, "", true); // WebYepV1 ?>
</div>

<?php
    $webyep_oCurrentLoop->loopEnd();
  }
  $goApp->oDocument = $oCurrentDocument;
?>