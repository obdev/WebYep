<table>

<?php
  $oCurrentDocument = $goApp->oDocument;
  $goApp->oDocument = new WYDocument(new WYURL(basename(__FILE__)));
  $goApp->oDocument->setDocumentInstance(0);
  foreach (WYLoopElement::aLoopIDs("globalLoop2") as $webyep_oCurrentLoop->iLoopID) {
    $webyep_oCurrentLoop->loopStart(false);
?>

  <tr>
    <td>
      <?php webyep_longText("Text", false, "", true); // WebYepV1 ?>
      <?php $webyep_oCurrentLoop->showEditButtons(); ?>
    </td>
  </tr>

<?php
    $webyep_oCurrentLoop->loopEnd();
  }
  $goApp->oDocument = $oCurrentDocument;
?>

</table>