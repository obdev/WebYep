<?php // WebYep init WebYepV1
/* ><table><tr><td bgcolor=white><h2>WebYep message: Error, PHP inactive</h2>
<font color=red>The PHP code in this page can not be executed!<ul>
<li>Are you launching this page directly form your harddisc (e.g. via Dreamweavers
"Preview in Browser" instead of accessing it via a webserver?</li>
<li>Has this file the correct file extension for PHP scripts?
WebYep pages must have the ".php" extension and <b>not</b> ".html" or ".htm"!</li>
</ul></font></td></tr></table><!--
*/
$webyep_sIncludePath = "./";
$iDepth = 0;
while (!file_exists($webyep_sIncludePath . "webyep-system")) {
  $iDepth++;
  if ($iDepth > 10) {
    error_log("webyep-system folder not found!", 0);
    echo "<html><head><title>WebYep</title></head><body><b>WebYep:</b> This page can not be displayed <br>Problem: The webyep-system folder was not found!</body></html>";
    exit;
  }
  $webyep_sIncludePath = ($webyep_sIncludePath == "./") ? ("../"):("$webyep_sIncludePath../");
}
if (file_exists("${webyep_sIncludePath}webyep-system/programm")) $webyep_sIncludePath .= "webyep-system/programm";
else $webyep_sIncludePath .= "webyep-system/program";
include("$webyep_sIncludePath/webyep.php");
// -->?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="Content-Script-Type" content="text/javascript" />
    <meta http-equiv="Content-Style-Type" content="text/css" />
    <title>WebYep Test &bull; Global Loop</title>
    <link rel="Stylesheet" type="text/css" href="style.css" />
  </head>
  <body>
    <div id="page">
      <div id="head">
        <div class="login"><?php webyep_logonButton(true); ?></div>
        <h1>Global Loop Examples</h1>
      </div>

      <div id="menu">
        <ul class="horizontal">
          <li><a href="index.html">Home</a></li>
          <li><a href="globalLoopTest11.php">Page 1.1</a></li>
          <li><a href="globalLoopTest12.php">Page 1.2</a></li>
          <li><a href="globalLoopTest21.php">Page 2.1</a></li>
          <li><a href="globalLoopTest22.php">Page 2.2</a></li>
        </ul>
      </div>

      <div id="content">
        <div class="rightColumn">
          <h3>News (table)</h3>
          <!-- LOOP -->
          <?php include('globalLoop2.php'); ?>
          <!-- END LOOP -->
        </div>
        <div class="leftColumn">
          <h2>Page 2.1</h2>
          <?php webyep_longText("PageContent", false, "", false); ?>
        </div>
      </div>

    </div>
  </body>
</html>
