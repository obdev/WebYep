<?php // WebYep init WebYepV1
/* ><table><tr><td bgcolor=white><h2>WebYep message: Error, PHP inactive</h2>
<font color=red>The PHP code in this page can not be executed!<ul>
<li>Are you launching this page directly form your harddisc (e.g. via Dreamweavers
"Preview in Browser" instead of accessing it via a webserver?</li>
<li>Has this file the correct file extension for PHP scripts?
WebYep pages must have the ".php" extension and <b>not</b> ".html" or ".htm"!</li>
</ul></font></td></tr></table><!--
*/
$webyep_sIncludePath = "./";
$iDepth = 0;
while (!file_exists($webyep_sIncludePath . "webyep-system")) {
  $iDepth++;
  if ($iDepth > 10) {
    error_log("webyep-system folder not found!", 0);
    echo "<html><head><title>WebYep</title></head><body><b>WebYep:</b> This page can not be displayed <br>Problem: The webyep-system folder was not found!</body></html>";
    exit;
  }
  $webyep_sIncludePath = ($webyep_sIncludePath == "./") ? ("../"):("$webyep_sIncludePath../");
}
if (file_exists("${webyep_sIncludePath}webyep-system/programm")) $webyep_sIncludePath .= "webyep-system/programm";
else $webyep_sIncludePath .= "webyep-system/program";
include("$webyep_sIncludePath/webyep.php");
// -->?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta http-equiv="Content-Type" content="text/html;charset=utf-8"/>
  <meta http-equiv="Content-Script-Type" content="text/javascript"/>
  <meta http-equiv="Content-Style-Type" content="text/css"/>
  <title>Slideshow</title>
  <style type="text/css">
    body {
      font: 12px/18px sans-serif;
      color: #002;
      margin: 0;
      padding: 0;
    }
    .page {
      width: 800px;
      margin: 0 auto;
    }
    .header {
      color: #004;
      text-shadow: 0 1px 0 #fff;
      border-radius: 0 0 8px 8px;
      background-color: #ddd;
      background: -moz-linear-gradient(top, #eee, #bbb);
      background: -webkit-gradient(linear, left top, left bottom, from(#eee), to(#bbb));
    }
    .logon {
      float: right;
      margin: 10px;
    }
    h1, h2 {
      margin: 0;
      padding: 10px;
    }
    .content {
      padding: 10px;
    }
    .WY_Slideshow {width: 640px; margin: 0 auto;}
    .WY_SlideshowPager {text-align: center}
    .WY_SlideshowPager a {color: #888; font: bold 12px/18px sans-serif; text-decoration: none; padding: 3px;}
    .WY_SlideshowPager a.activeSlide {color: #222;}
    .WY_SlideshowPager a:hover {color: #800;}
    .WebYepGalleryImage {padding: 10px;}
  </style>

  <!-- === Using a namespaced jQuery library with WebYep === -->

  <!-- include jQuery library -->
  <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>

  <!-- include Cycle plugin -->
  <script type="text/javascript" src="http://malsup.github.com/jquery.cycle.all.js"></script>

  <!-- namespacing jQuery and all plugins loaded so far -->
  <script type="text/javascript">/*<![CDATA[*/
    var WY = window.WY || {}; WY.$ = jQuery.noConflict(true);
  /*]]>*/</script>

  <!--  initialize the slideshow when the DOM is ready -->
  <script type="text/javascript">/*<![CDATA[*/
    WY.$(document).ready(function() {
      if (!WY.$('.WY_Slideshow').find('.WebYepLoopAddButton').length) {
        WY.$('.WY_Slideshow').cycle({
          fx:    'fade',              // options: http://jquery.malsup.com/cycle/options.html
          pager: '.WY_SlideshowPager'
        });
      }
    });
  /*]]>*/</script>
  <!-- === End of demo code for WY_Slideshow === -->
</head>
<body>
  <div class="page">
    <div class="header">
      <div class="logon"><?php webyep_logonButton(true); ?></div>
      <h1>Slideshow with WebYep</h1>
      <h2>&copy; 2012 Objective Development Software GmbH</h2>
    </div>
    <div class="content">
      <div>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse vel velit et metus rhoncus viverra nec eget nunc.
        In ullamcorper dui id nibh fringilla convallis. Suspendisse potenti. Cum sociis natoque penatibus et magnis dis parturient
        montes, nascetur ridiculus mus.</p>
      </div>

      <!-- the HTML/WebYep part of the slideshow -->
      <div class="WY_Slideshow">
        <?php foreach (WYLoopElement::aLoopIDs("SlideshowLoop") as $webyep_oCurrentLoop->iLoopID) {
          $webyep_oCurrentLoop->loopStart(true);
          webyep_image("SlideshowImage", false, '', '', '', 640, 480, false);
          $webyep_oCurrentLoop->loopEnd();
        } ?>
      </div>
      <div class="WY_SlideshowPager"></div>

      <div>
        <p>Morbi at sapien orci. Fusce augue arcu, feugiat vel condimentum sed, rutrum nec est. Ut sit amet lacus ipsum, non mattis eros.
        Cras consectetur cursus urna sed laoreet. Sed non libero ut purus pharetra adipiscing. Suspendisse fermentum massa et felis
        tempor iaculis. Fusce aliquam rhoncus nisl, at pulvinar dui lobortis non. Duis ac arcu lorem.</p>
      </div>

      <div>
        <h2>Gallery</h2>
        <?php webyep_gallery("GalleryName", false, 240, 280, 3, 600, 700, 100); ?>
      </div>

      <div>
        <p>Integer vehicula, felis venenatis tempus malesuada, tellus nisi ullamcorper velit, id feugiat dui enim quis ante. Nam vitae
        nisi tortor, eget gravida mauris. Sed feugiat dolor et justo pretium suscipit? Nulla facilisi. Cras lobortis nulla eros, ac
        placerat ligula. Nam lacinia ullamcorper nibh, non vulputate nunc iaculis ut.</p>
      </div>

      <div>
        <h2>Image</h2>
        <?php webyep_image("Photo", false, '', "", "", 300, 200, true); ?>
        <p>Duis dui tellus, malesuada eget blandit vitae, blandit sed turpis. Curabitur elit nisi, tempor sed condimentum quis, porta
        quis enim. Phasellus ornare erat sem. Pellentesque habitant morbi tristique senectus et malesuada fames ac turpis egestas.</p>
      </div>
    </div>
  </div>
</body>
</html>