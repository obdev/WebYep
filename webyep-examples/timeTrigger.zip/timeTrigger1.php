<?php // WebYep init WebYepV1
/* ><table><tr><td bgcolor=white><h2>WebYep message: Error, PHP inactive</h2>
<font color='red'>The PHP code in this page can not be executed!<ul>
<li>Are you launching this page directly form your harddisc (e.g. via Dreamweavers "Preview in Browser" instead of accessing it via a webserver?</li>
<li>Has this file the correct file extension for PHP scripts? WebYep pages must have the ".php" extension and <b>not</b> ".html" or ".htm"!</li>
</ul></font></td></tr></table><!--
*/
$webyep_sIncludePath = './'; $iDepth = 0;
while (!file_exists($webyep_sIncludePath . 'webyep-system')) {if ($iDepth++ > 10) {error_log('webyep-system folder not found!', 0);
echo '<html><head><title>WebYep</title></head><body><b>WebYep:</b> This page can not be displayed<br>Problem: The webyep-system folder was not found!</body></html>';
exit;} $webyep_sIncludePath = ($webyep_sIncludePath == './') ? ('../'):("$webyep_sIncludePath../");}
if (file_exists("${webyep_sIncludePath}webyep-system/programm")) $webyep_sIncludePath .= 'webyep-system/programm';
else $webyep_sIncludePath .= 'webyep-system/program';
include("$webyep_sIncludePath/webyep.php");
// -->?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta http-equiv="Content-Type" content="text/html;charset=utf-8"/>
  <meta http-equiv="Content-Style-Type" content="text/css"/>
  <meta http-equiv="Content-Script-Type" content="text/javascript"/>
  <title>WebYep Examples :: Time Triggered Elements</title>
  <style type="text/css">
    /* general styles */
    html, body {margin:0; padding:0;}
    body {overflow-y:scroll}
    .page {width:800px; margin:0 auto; font:14px sans-serif;}
    .header {background-color:#eee; border-radius: 0 0 8px 8px; box-shadow:0 0 1px #888;}
    .header h1, .header h2, .header p {margin:0; padding:10px;}
    .header h1 {font-size:1.3em; color:orange; text-shadow:0 1px 0 #888;}
    .header h2 {font-size:1.1em;}
    .header p {font-size:1.0em;}
    .header p span {color:#911;}
    .logon {float:right; margin:5px; padding:2px 2px 0 1px; border-radius:6px; background-color:#ccc;}
    .content {padding:10px;}
    /* styles for the bar above the scheduled content */
    .ttControls {background-color:#ddd; border:solid 1px #ccc; border-radius:5px; padding: 0 7px 5px; height:25px; clear:both;}
    .ttControls div {float:left;}
    .ttControls .ttDate {padding:11px 0 0 25px;}
    .ttControls .WebYepShortTextEditButton {float:right; padding: 0 0 1px 3px; margin-top:-10px;}
    /* styles for the scheduled content */
    .content .WebYepRichTextEditButton {float:left; padding: 0 3px 1px 0;}
    .content h2 {margin:3px 0; font-size:1.1em;}
  </style>
</head>
<body>
  <div class="page">
    <div class="header">
      <div class="logon"><?php webyep_logonButton(true); ?></div>
      <h1>WebYep Examples</h1><h2>Time Triggered Elements</h2>
      <p>
        Use this date format: <span>year</span>-<span>month</span>-<span>day</span> <span>hour</span>:<span>minute</span>:<span>second</span><br />
        If a date field is left blank it will be ignored. When a date is entered, the date is mandatory, the time is optional.<br />
        Valid entries are: <span>2011-01-15</span> or <span>2011-01-15 15:30</span> or <span>2011-01-15 15:30:00</span>
      </p>
    </div>
    <div class="content">

      <?php if (webyep_bIsEditMode()) {
          echo '<div class="ttControls"><div class="ttDate"><b>Publication Start:</b> ';
          webyep_shortText("PublicationStartDate", false);
          echo '</div><div class="ttDate"><b>Publication End:</b> ';
          webyep_shortText("PublicationEndDate", false);
          echo '</div></div>';
        }
        if (webyep_bIsEditMode() || (
            (
              strtotime('now') >= strtotime(webyep_sShortTextContent('PublicationStartDate', false)) ||
              webyep_sShortTextContent('PublicationStartDate', false) == ''
            ) && (
              strtotime('now') <= strtotime(webyep_sShortTextContent('PublicationEndDate', false)) ||
              webyep_sShortTextContent('PublicationEndDate', false) == ''
            )
        )) {
      ?>

      <!-- This is the scheduled content -->
      <h2><?php webyep_shortText("Headline", false); ?></h2>
      <div><?php webyep_richText("Text", false, "", true); ?></div>
      <!-- scheduled content ends here -->

      <?php } ?>

    </div>
  </div>
</body>
</html>